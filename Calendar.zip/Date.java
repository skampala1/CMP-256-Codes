package calendar;

import java.time.DayOfWeek;
import java.time.LocalDate;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
public class Date{
    private LocalDate date;
    
    {
        date = LocalDate.now();
    }
    
    public DayOfWeek getDayOfWeek(){
        return date.getDayOfWeek();
    }
    
    public int getDay(){
        return date.getDayOfMonth();
    }
    
    public void thisMonth(){
        date = LocalDate.now();
    }
    
    public void gotoPrevMonth(){
        date = date.minusMonths(1);
    }
    
    public void gotoNextMonth(){
        date = date.plusMonths(1);
    }
    
    public int getMaxDays(){
        return date.lengthOfMonth();
    }
    
    public DayOfWeek getFirstDay(){
        return date.withDayOfMonth(1).getDayOfWeek();
    }
    
    public int getMonth(){
        return date.getMonthValue();
    }
    
    public int getNextMonth(){
        LocalDate kk = date.withDayOfMonth(1);
        return kk.plusMonths(1).getMonthValue();
    }
    
    public int getPrevMonth(){
        LocalDate kk = date.withDayOfMonth(1);
        return kk.minusMonths(1).getMonthValue();
    }
    
    public int getYear(){
        return date.getYear();
    }
}
