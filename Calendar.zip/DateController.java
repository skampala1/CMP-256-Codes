package calendar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.DayOfWeek;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
public class DateController {
    private Days days;
    private ButtonPanel buttonPanel;
    private DateView dateView;
    private Date date;
    
    public DateController(Days days, ButtonPanel buttonPanel, DateView dateView, Date date){
        this.days = days;
        this.buttonPanel = buttonPanel;
        this.dateView = dateView;
        this.date = date;
        
        days.updateMonth(returnMonth(date.getMonth()), Integer.toString(date.getYear()));
        buttonPanel.updateMonths(returnMonth(date.getPrevMonth()),returnMonth(date.getNextMonth()));
        dateView.updateDate(returnDay(date.getFirstDay()), date.getMaxDays());
        
        this.buttonPanel.getNextButton().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                date.gotoNextMonth();
                days.updateMonth(returnMonth(date.getMonth()), Integer.toString(date.getYear()));
                buttonPanel.updateMonths(returnMonth(date.getPrevMonth()),returnMonth(date.getNextMonth()));
                dateView.updateDate(returnDay(date.getFirstDay()), date.getMaxDays());
            } 
        });
        
        this.buttonPanel.getPrevButton().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                date.gotoPrevMonth();
                days.updateMonth(returnMonth(date.getMonth()), Integer.toString(date.getYear()));
                buttonPanel.updateMonths(returnMonth(date.getPrevMonth()),returnMonth(date.getNextMonth()));
                dateView.updateDate(returnDay(date.getFirstDay()), date.getMaxDays());
            } 
        });
    }
    
    private String returnMonth(int month){
        switch(month){
            case 1: return "January";
            case 2: return "February";
            case 3: return "March";
            case 4: return "April";
            case 5: return "May";
            case 6: return "June";
            case 7: return "July";
            case 8: return "August";
            case 9: return "September";
            case 10: return "October";
            case 11: return "November";
            case 12: return "December";
        }
        return null;
    }
    
    private int returnDay(DayOfWeek week){
        switch(week.getValue()){
            case 1: return 2;
            case 2: return 3;
            case 3: return 4;
            case 4: return 5;
            case 5: return 6;
            case 6: return 7;
            case 7: return 1;
        }
        return 0;
    }
}
