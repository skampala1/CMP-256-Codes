package calendar;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
public class DateView extends View{
    private int maxDays, firstDay;
    private JLabel []columns;
    {
        this.setLayout(new GridLayout(5,8));
        columns = new JLabel[35];
        firstDay = 3;
        maxDays = 31;
        
        for(int i=0;i<columns.length;i++){
            columns[i]=new JLabel("");
            columns[i].setBorder(BorderFactory.createLineBorder(Color.black));
            columns[i].setHorizontalAlignment(JLabel.CENTER);
            this.add(columns[i]);
        }
        int k=1;
        for(int i=firstDay-1;k<=maxDays;k++){
            if(i>=columns.length) i=0;
            columns[i++].setText(Integer.toString(k));
        }    
    }
    
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        this.setBackground(Color.white);
    }
    
    public void updateDate(int firstDay, int maxDays){
        this.firstDay = firstDay;
        this.maxDays = maxDays;
        
        for(int i=0;i<columns.length;i++)
            columns[i].setText("");
        
        int k=1;
        for(int i=firstDay-1;k<=maxDays;k++){
            if(i>=columns.length) i=0;
            columns[i++].setText(Integer.toString(k));
        }
        
        repaint();
    }
}
