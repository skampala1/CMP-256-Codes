package calendar;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JFrame;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
public class Calendar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                JFrame frame = new JFrame();
                frame.setTitle("arrtCal");
                frame.setSize(900,500);
                
                Days day= new Days();
                ButtonPanel panel = new ButtonPanel();
                DateView view = new DateView();
                Date date = new Date();
                DateController controller = new DateController(day, panel, view, date);
                
                day.setPreferredSize(new Dimension(frame.getHeight()/10,frame.getWidth()/10));
                panel.setPreferredSize(new Dimension(frame.getHeight()/20,frame.getWidth()/20));
                view.setPreferredSize(new Dimension(frame.getHeight()-day.getHeight()-panel.getHeight(),frame.getWidth()-day.getWidth()-panel.getWidth()));
                
                frame.add(day, BorderLayout.NORTH);
                frame.add(panel, BorderLayout.SOUTH);
                frame.add(view);

                frame.setVisible(true); 
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   
    }
}
