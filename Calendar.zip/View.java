package calendar;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
public abstract class View extends JPanel {
    @Override
    public void paintComponents(Graphics g){
        super.paintComponent(g);
        this.setBackground(Color.white);
    }
}
