package tempdisplay;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
class TempModel {
    private int temp; 

    public int getTemperature() {
        return temp;
    }
    
    public void increase(){
        if(temp<50)
            ++temp;
    }
    
    public void decrease(){
        if(temp>0)
            --temp;
    }

    public void setTemperature(int temperature) {
        this.temp = temperature;
    }
    
}
