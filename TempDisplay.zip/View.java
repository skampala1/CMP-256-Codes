package tempdisplay;

import java.awt.Graphics;
import javax.swing.JComponent;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
abstract class View extends JComponent{
    protected int kk = 0; //helper vairable for paint
    
    @Override
    public void paintComponent(Graphics g){
        
    }
    
    public void paintTemp(int kk){
        
    }
}
