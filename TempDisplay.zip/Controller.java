package tempdisplay;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
class Controller {
    private TempModel model;
    private ButtonsControl control;
    private ArrayList<View> views;
    
    public Controller(ArrayList<View> views, ButtonsControl control, TempModel model){
        this.views = views;
        this.control = control;
        this.model = model;
        
        model.setTemperature(20);
        for(View i: views)
            i.paintTemp(model.getTemperature());
 
        control.getIncrease().addActionListener(new ActionListener()
        {            
            @Override
            public void actionPerformed(ActionEvent e) {
                model.increase();
                for(View i: views)
                    i.paintTemp(model.getTemperature());
            }
        });

        control.getDecrease().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                model.decrease();
                for(View i: views)
                    i.paintTemp(model.getTemperature());
            }
        });
    }
}
