package tempdisplay;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Color;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
class DigitalView extends View{
    @Override
    public void paintComponent(Graphics g){
        g.drawString("Digital View", 20, 50);
        
        Font font = new Font("Arial",Font.BOLD,40);
        g.setFont(font);
        g.setColor(Color.red);
        g.drawString(Integer.toString(kk)+" C", 20, 120);
    }
    
    @Override
    public void paintTemp(int kk){
        this.kk = kk;
        repaint();
    }
}
