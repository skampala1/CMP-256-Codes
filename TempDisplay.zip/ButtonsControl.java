package tempdisplay;

import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
class ButtonsControl extends JPanel{
    private JButton increase = new JButton("Increase");
    private JButton decrease = new JButton("Decrease");
    
    public JButton getIncrease(){
        return increase;
    }
    
    public JButton getDecrease(){
        return decrease;
    }
    
    @Override
    public void paintComponent(Graphics g){
        increase.setPreferredSize(new Dimension(100,25));
        decrease.setPreferredSize(new Dimension(100,25));
        this.add(increase);
        this.add(decrease);
    }
}
