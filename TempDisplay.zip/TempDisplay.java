package tempdisplay;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
public class TempDisplay {
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override public void run() {
				//Create the frame and buttons
				JFrame frame = new JFrame("Temperature Views");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); frame.setResizable(false);
								

				//1. Create the MODEL class, to store the temperature and provide related operations
				TempModel theModel = new TempModel();

				//2. Create two VIEWs to display the temperature digitally and graphically
				ArrayList<View> theViews = new ArrayList<>();

				DigitalView tDigital = new DigitalView();
				tDigital.setPreferredSize(new Dimension(130, 80));  
				theViews.add(tDigital);

				GraphicalView tGraphic = new GraphicalView();
				tGraphic.setPreferredSize(new Dimension(130, 270));  
				theViews.add(tGraphic);
				
				//Create a class that contains the increase/decrease buttons
				//the listeners of the buttons should be implemented in the controller
				ButtonsControl buttons = new ButtonsControl();
				

				//3. Create the CONTROLLER, that handles interactions between the views and the model
				Controller theController = new Controller(theViews, buttons, theModel);


				//Add the components to the frame
				frame.add(tDigital, BorderLayout.WEST);
				frame.add(tGraphic, BorderLayout.EAST);
				frame.add(buttons, BorderLayout.NORTH);
				frame.pack();
				frame.setVisible(true);
				
			}});
	}

}

