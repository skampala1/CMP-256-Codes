package tempdisplay;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.awt.geom.RoundRectangle2D;

/**
 *
 * @author Asif Rasheed, Shaham Kampala
 */
class GraphicalView extends View{
    @Override
    public void paintComponent(Graphics g){
        g.drawString("Graphical View", 20, 50);
        Graphics2D g2 = (Graphics2D) g;
        
        g2.drawRoundRect(55, 60, 30, 150, 30, 30);
        g2.draw(new Ellipse2D.Double(45, 190, 50, 50));
        g2.setColor(Color.red);
        g2.fill(new Ellipse2D.Double(45, 190, 50, 50));
        g2.fillRoundRect(55, 190-kk, 30, kk+20, 30, 30);
        g2.setColor(Color.black);
        
    }
    
    @Override
    public void paintTemp(int kk){
        this.kk = (kk*3)-20;
        repaint();
    }
}
